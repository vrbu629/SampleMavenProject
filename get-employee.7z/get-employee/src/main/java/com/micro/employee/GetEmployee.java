package com.micro.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetEmployee {

	public static void main(String[] args) {
		System.out.println("******************Test Veera ----Getting the Employee Data ");
		SpringApplication.run(GetEmployee.class, args);
	}

}
