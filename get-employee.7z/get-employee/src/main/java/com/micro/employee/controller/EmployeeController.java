package com.micro.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.micro.employee.model.Employee;
import com.micro.employee.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
    private EmployeeService employeeService;
	
    @RequestMapping("/getemp")
	public Employee getEmployeeByFirstName(@RequestParam String fName) {
		System.out.println("HI Veera");
		Employee emp=employeeService.getEmployee(fName);
		//return emp.toString();
		return emp;
	}

}
